import mpl_toolkits.mplot3d.axes3d as p3
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.animation import FuncAnimation
from scipy.integrate import odeint
from matplotlib import animation

N = 200
t = np.linspace(0, 1, N)
a = 3.22
b = 3.01232
c = 2
g = 9.81

def func(s,t):
     x, v_x, y, v_y, z, v_z = s
     
     dxdt = v_x
     dv_xdt = (x/a**2) * (g - (v_x**2/a**2) - (v_y**2/b**2) - (v_z**2/c**2)) / ((x**2/a**4) + (y**2/b**4) +(z**2/c**4))
     
     dydt = v_y
     dv_ydt = (y/b**2) * (g - (v_x**2/a**2) - (v_y**2/b**2) - (v_z**2/c**2)) / ((x**2/a**4) + (y**2/b**4) +(z**2/c**4))
     
     dzdt = v_z
     dv_zdt = -g + (z/c**2) * (g - (v_x**2/a**2) - (v_y**2/b**2) - (v_z**2/c**2)) / ((x**2/a**4) + (y**2/b**4) +(z**2/c**4))
     
     return dxdt, dv_xdt, dydt, dv_ydt, dzdt, dv_zdt
     
x0 = a
v_x0 = 0 
 
y0= b
v_y0 = 0
 
z0 = 0
v_z0 = 0
 
s0 = (x0,v_x0,y0,v_y0,z0,v_z0)
sol = odeint(func, s0, t)
 
fig = plt.figure()
ax = p3.Axes3D(fig)

ball, = ax.plot(sol[:,0], sol[:,2], sol[:,4], 'o', color='r')
line, = ax.plot(sol[:,0], sol[:,2], sol[:,4], '-', color='r')

def anim(i) :
    ball.set_data(sol[i,1],sol[i,2])
    ball.set_3d_properties(sol[i,4])
    
    line.set_data(sol[:i,1],sol[:i,2])
    line.set_3d_properties(sol[:i,4])
    
ax.set_xlim3d([-5, 5])
ax.set_xlabel('X')

ax.set_ylim3d([-5.0, 5.0])
ax.set_ylabel('Y')

ax.set_zlim3d([-5.0, 5.0])
ax.set_zlabel('Z')    
 
ani = animation.FuncAnimation(fig, anim, N, interval = 50)

phi = np.linspace(0, 2**np.pi, 100)
theta = np.linspace(0, np.pi, 100)
x = 0.651*a * np.outer(np.cos(phi), np.sin(theta))
y = 0.651*b * np.outer(np.sin(phi), np.sin(theta))
z = 0.651*c * np.outer(np.ones(np.size(phi)), np.cos(theta))
ax.plot_surface(x,y,z, color='b')


plt.show()
ani.save('gifka.gif')
 
 
 
     