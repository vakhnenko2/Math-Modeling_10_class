import mpl_toolkits.mplot3d.axes3d as p3
import matplotlib.pyplot as plt
import numpy as np
from scipy.integrate import odeint
from matplotlib import animation

N = 200
t = np.linspace(0, 4, N)
g = 9.81

def func(s,t):
     (x, v_x, y, v_y, z, v_z) = s
     
     dxdt = v_x     
     dv_xdt =  ((3*g*z)/(z**2+x**2))*x
     
     dydt = v_y
     dv_ydt = 0
     
     dzdt = v_z 
     dv_zdt = -g +(3*g*z)/(z**2 + x**2)*z
     
     return dxdt, dv_xdt, dydt, dv_ydt, dzdt, dv_zdt    
     
x0 = 1
v_x0 = 0 
 
y0= 0
v_y0 = 1
 
z0 = 0
v_z0 = 0     

s0 = (x0,v_x0,y0,v_y0,z0,v_z0)
sol = odeint(func, s0, t)
 
fig = plt.figure()
ax = p3.Axes3D(fig)

ball, = ax.plot(sol[:,0], sol[:,2], sol[:,4], 'o', color='r')
line, = ax.plot(sol[:,0], sol[:,2], sol[:,4], '-', color='r')

def anim(i) :
    ball.set_data(sol[i,0],sol[i,2])
    ball.set_3d_properties(sol[i,4])
    
    line.set_data(sol[:i,0],sol[:i,2])
    line.set_3d_properties(sol[:i,4])
    
#ax.set_xlim3d([-5, 5])
#ax.set_xlabel('X')
#
#ax.set_ylim3d([-5.0, 5.0])
#ax.set_ylabel('Y')
#
#ax.set_zlim3d([-5.0, 5.0])
#ax.set_zlabel('Z')    
 

ani=animation.FuncAnimation(fig, anim, N, interval=50)

y = np.linspace(0, 2**np.pi, 100)
F = np.linspace(0, -np.pi, 100)
R = 1

x = R * np.outer(np.ones(np.size(t)), np.cos(F))
y = np.outer(t, np.ones(np.size(F)))
z = R * np.outer(np.ones(np.size(t)), np.sin(F))
ax.plot_surface(x, y, z, color='b')

ani.save('GIFka1.gif')

    
    
    
    
    






